import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.io.File;
import java.io.FileWriter;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

public class AdvancedEdgeCasesTest {

    private String tempFilePath;

    @BeforeEach
    public void setUp() throws Exception {
        File tempFile = File.createTempFile("edge_case_", ".txt");
        tempFile.deleteOnExit();
        tempFilePath = tempFile.getAbsolutePath();
    }

    @Test
    public void testLateSubmissionDetection() {
        // Create an assignment with a due date in the past
        Assignment pastAssignment = new Assignment("Old Lab", "01/01/2020 23:59", "Past due", 100.0);
        pastAssignment.submitWork("student", tempFilePath);

        Submission sub = pastAssignment.getSubmissionForStudent("student");
        assertTrue(sub.isSubmitted(), "Work should be marked as submitted");
        assertTrue(sub.isLate(), "Submission past the due date should be flagged as late");
    }

    @Test
    public void testQuizRemainingSecondsTimer() {
        Quiz quiz = new Quiz("Timed Quiz", 10, "12/31/2026 23:59");
        quiz.startAttempt("student");

        long remainingSecs = quiz.getRemainingSeconds("student");
        // 10 minutes * 60 seconds = 600 seconds max
        assertTrue(remainingSecs > 0 && remainingSecs <= 600, "Remaining seconds should be within the 10-minute window");
    }

    @Test
    public void testCombinedCourseGradeWithHomeworkAndQuizzes() {
        Course course = new Course("CS3141", "R01", "Software Engineering", "Dr. Smith", "smith@univ.edu");
        
        // Add Assignment (Homework category weight: 0.40)
        Assignment hw = new Assignment("HW1", "12/31/2030 23:59", "Desc", 100.0);
        course.getAssignments().add(hw);
        hw.submitWork("student", tempFilePath);
        hw.getSubmissionForStudent("student").setGrade("80%"); // 80 points earned

        // Add Quiz (Quiz category weight: 0.30)
        Quiz quiz = new Quiz("Quiz 1", 15, "12/31/2030 23:59");
        quiz.addQuestion(new QuizQuestion("Q1?", Arrays.asList("A", "B"), 0));
        course.addQuiz(quiz);
        quiz.gradeQuiz("student", Arrays.asList(0)); // 100% correct score

        double percentage = course.getGradePercentage("student");
        // Homework cat avg = 80.0, Quiz cat avg = 100.0
        // Total accounted weight = 0.40 + 0.30 = 0.70
        // Weighted score = (80.0 * 0.40) + (100.0 * 0.30) = 32.0 + 30.0 = 62.0
        // Final percentage = 62.0 / 0.70 = 88.571%
        assertEquals(88.571, percentage, 0.01, "Combined weighted grade calculation should factor both homework and quizzes correctly");
        assertEquals("B", course.getLetterGrade("student"));
    }

    @Test
    public void testAuthServiceBatchUserImport() throws Exception {
        File csvFile = File.createTempFile("users_import", ".csv");
        csvFile.deleteOnExit();

        try (FileWriter writer = new FileWriter(csvFile)) {
            writer.write("student2,pass2,student\n");
            writer.write("prof2,profpass2,instructor\n");
        }

        int importedCount = AuthService.batchImportUsers(csvFile);
        assertEquals(2, importedCount, "Batch import should successfully parse and register 2 users");

        AuthService auth = new AuthService();
        assertTrue(auth.authenticate("student2", "pass2"));
        assertEquals("instructor", auth.getRole("prof2"));
    }
}