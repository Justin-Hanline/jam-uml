import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.io.File;
import java.util.Arrays;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Adversarial stress tests targeting edge cases, malformed data, and potential failure points.
 */
public class StressTestBreakTheLMS {

    private Course course;
    private Assignment assignment;
    private String tempFilePath;

    @BeforeEach
    public void setUp() throws Exception {
        course = new Course("CS4321", "R02", "Advanced Algorithms", "Dr. Turing", "turing@univ.edu");
        assignment = new Assignment("Final Project", "12/15/2026 23:59", "Complete implementation", 100.0);
        course.getAssignments().add(assignment);

        File tempFile = File.createTempFile("stress_", ".tmp");
        tempFile.deleteOnExit();
        tempFilePath = tempFile.getAbsolutePath();
    }

    @Test
    public void testDivisionByZeroFractionGrade() {
        // Attempting to break fraction parsing with a zero denominator (e.g., "5/0")
        assignment.submitWork("student", tempFilePath);
        assignment.getSubmissionForStudent("student").setGrade("5/0");

        // Should not throw ArithmeticException or crash; should default score contribution safely
        double pct = course.getGradePercentage("student");
        assertTrue(pct >= 0.0, "Zero denominator fractions should be handled safely without crashing");
    }

    @Test
    public void testMalformedNonNumericGrades() {
        // Injecting arbitrary non-numeric text into grades
        assignment.submitWork("student", tempFilePath);
        Submission sub = assignment.getSubmissionForStudent("student");

        sub.setGrade("Incomplete");
        double pct1 = course.getGradePercentage("student");
        
        sub.setGrade("abc/xyz");
        double pct2 = course.getGradePercentage("student");

        // Malformed strings should be caught by try-catch blocks and ignored safely
        assertTrue(pct1 >= 0.0 || pct1 == -1.0, "Malformed text grades should not throw unhandled exceptions");
    }

    @Test
    public void testOutOfBoundsQuizDraftAnswers() {
        Quiz quiz = new Quiz("Stress Quiz", 10, "12/31/2026 23:59");
        quiz.addQuestion(new QuizQuestion("Q1?", Arrays.asList("Yes", "No"), 0));

        // Attempting to save draft answers with negative indices or out-of-bounds indices
        assertDoesNotThrow(() -> {
            quiz.saveDraftAnswer("student", -5, 1);
            quiz.saveDraftAnswer("student", 999, 1);
        }, "Saving out-of-bound draft answers should be safely ignored by bounds checks");
    }

    @Test
    public void testCorruptedDateStringFallbacks() {
        // Providing completely garbage date strings to assignment and quiz
        Assignment badDateAssign = new Assignment("Bad Date", "not-a-date", "Desc");
        Quiz badDateQuiz = new Quiz("Bad Date Quiz", 15, "99/99/9999 99:99");

        // Should successfully fall back to default future deadlines instead of throwing DateTimeParseException
        assertNotNull(badDateAssign.getDueDate());
        assertNotNull(badDateQuiz.getDueDate());
    }

    @Test
    public void testNullAndBlankRosterInjections() {
        // Attempting to inject null, empty strings, or whitespace into course rosters and auth
        int initialSize = course.getEnrolledStudents().size();
        
        course.addStudent(null);
        course.addStudent("   ");
        course.addStudent("");

        assertEquals(initialSize, course.getEnrolledStudents().size(), "Null or blank student usernames should be rejected");

        AuthService auth = new AuthService();
        assertNull(auth.getRole(null));
        assertNull(auth.getRole("   "));
        assertFalse(auth.authenticate(null, "password123"));
    }

    @Test
    public void testEmptyCourseGradeCalculations() {
        // Creating a brand-new course with zero assignments and zero quizzes
        Course emptyCourse = new Course("EMPTY101", "R01", "Empty", "Staff", "staff@univ.edu");
        emptyCourse.clearRoster();

        // Should return -1.0 (N/A) instead of dividing by zero or throwing NaN errors
        assertEquals(-1.0, emptyCourse.getGradePercentage("student"), 0.001);
        assertEquals("N/A", emptyCourse.getLetterGrade("student"));
    }
}