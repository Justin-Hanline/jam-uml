import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.io.File;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Comprehensive master test suite covering all logic across the JAME LMS backend.
 */
public class ComprehensiveLMSTest {

    private String tempFilePath;

    @BeforeEach
    public void setUp() throws Exception {
        // Create a temporary file to simulate student submission uploads
        File tempFile = File.createTempFile("test_sub_", ".txt");
        tempFile.deleteOnExit();
        tempFilePath = tempFile.getAbsolutePath();
    }

    // ==========================================
    // 1. AUTH SERVICE TESTS
    // ==========================================
    @Test
    public void testAuthServiceAuthenticationAndRoles() {
        AuthService auth = new AuthService();
        
        // Seed accounts should authenticate correctly
        assertTrue(auth.authenticate("student", "password123"));
        assertTrue(auth.authenticate("teacher", "teacher123"));
        assertTrue(auth.authenticate("admin", "admin2026"));

        // Invalid credentials should fail
        assertFalse(auth.authenticate("student", "wrongpassword"));
        assertFalse(auth.authenticate("nonexistent", "password123"));
        assertFalse(auth.authenticate(null, null));

        // Role lookups (case-insensitive)
        assertEquals("student", auth.getRole("STUDENT"));
        assertEquals("instructor", auth.getRole("teacher"));
        assertEquals("admin", auth.getRole("admin"));
        assertNull(auth.getRole("unknownUser"));

        // Instructor permission checks
        assertTrue(AuthService.isRegisteredInstructor("teacher"));
        assertTrue(AuthService.isRegisteredInstructor("admin"));
        assertFalse(AuthService.isRegisteredInstructor("student"));
        assertFalse(AuthService.isRegisteredInstructor(null));
    }

    @Test
    public void testAuthServiceRegistrationAndPasswordUpdate() {
        AuthService auth = new AuthService();
        
        AuthService.registerUser("newprof", "prof123", "instructor");
        assertTrue(auth.authenticate("newprof", "prof123"));
        assertEquals("instructor", auth.getRole("newprof"));

        // Password update
        assertTrue(auth.updatePassword("newprof", "newpass456"));
        assertFalse(auth.authenticate("newprof", "prof123"));
        assertTrue(auth.authenticate("newprof", "newpass456"));
    }

    // ==========================================
    // 2. AUDIT LOG TESTS
    // ==========================================
    @Test
    public void testAuditLogTracking() {
        AuditLog.log("admin", "Created test course");
        List<AuditLog.AuditEntry> entries = AuditLog.getEntries();

        assertFalse(entries.isEmpty());
        AuditLog.AuditEntry latest = entries.get(0);
        assertEquals("admin", latest.getActor());
        assertEquals("Created test course", latest.getAction());
        assertNotNull(latest.getTimestamp());
    }

    // ==========================================
    // 3. SUBMISSION TESTS
    // ==========================================
    @Test
    public void testSubmissionRecordingAndHistory() {
        Submission sub = new Submission();
        assertFalse(sub.isSubmitted());
        assertEquals("Pending", sub.getGrade());

        sub.recordSubmission(tempFilePath, false);
        assertTrue(sub.isSubmitted());
        assertFalse(sub.isLate());
        assertEquals(tempFilePath, sub.getSubmittedFilePath());
        assertEquals(1, sub.getSubmissionHistory().size());

        sub.setGrade("92%");
        sub.setFeedback("Excellent work!");
        assertEquals("92%", sub.getGrade());
        assertEquals("Excellent work!", sub.getFeedback());
    }

    // ==========================================
    // 4. QUIZ & QUIZ QUESTION TESTS
    // ==========================================
    @Test
    public void testQuizQuestionValidation() {
        List<String> options = Arrays.asList("Option A", "Option B", "Option C");
        QuizQuestion q = new QuizQuestion("What is Java?", options, 1);

        assertEquals("What is Java?", q.getQuestionText());
        assertEquals(3, q.getOptions().size());
        assertTrue(q.isCorrect(1));
        assertFalse(q.isCorrect(0));

        // Invalid constructor arguments should throw exception
        assertThrows(IllegalArgumentException.class, () -> new QuizQuestion("Bad", Arrays.asList("OnlyOne"), 0));
        assertThrows(IllegalArgumentException.class, () -> new QuizQuestion("Bad", options, 5));
    }

    @Test
    public void testQuizAttemptAndGrading() {
        Quiz quiz = new Quiz("Unit 1 Quiz", 15, "12/31/2026 23:59");
        assertEquals("Unit 1 Quiz", quiz.getTitle());
        assertEquals(15, quiz.getTimeLimitMinutes());

        List<String> opts = Arrays.asList("True", "False");
        quiz.addQuestion(new QuizQuestion("Is sky blue?", opts, 0));
        quiz.addQuestion(new QuizQuestion("Is 2+2=5?", opts, 1));

        quiz.startAttempt("student");
        assertTrue(quiz.getRemainingSeconds("student") > 0);

        // Grade quiz with student answers: correct index 0, correct index 1 -> 2/2 correct (100%)
        String scoreResult = quiz.gradeQuiz("student", Arrays.asList(0, 1));
        assertEquals("100% (2/2 correct)", scoreResult);
        assertTrue(quiz.hasStudentCompleted("student"));
        assertEquals("100% (2/2 correct)", quiz.getScoreForStudent("student"));
    }

    // ==========================================
    // 5. ASSIGNMENT TESTS
    // ==========================================
    @Test
    public void testAssignmentCreationAndSubmission() {
        Assignment assignment = new Assignment("Lab 1", "10/30/2026 23:59", "Build a list.", 50.0);
        assertEquals("Lab 1", assignment.getName());
        assertEquals(50.0, assignment.getPointsPossible());
        assertEquals("10/30/2026 23:59", assignment.getDueDate());

        assignment.submitWork("student", tempFilePath);
        Submission sub = assignment.getSubmissionForStudent("student");
        assertTrue(sub.isSubmitted());
    }

    // ==========================================
    // 6. COURSE FILE & ANNOUNCEMENT TESTS
    // ==========================================
    @Test
    public void testCourseFileAndAnnouncement() {
        CourseFile file = new CourseFile("Lecture1.pdf", tempFilePath, "Dr. Smith");
        assertEquals("Lecture1.pdf", file.getFileName());
        assertEquals("Dr. Smith", file.getUploader());

        Announcement ann = new Announcement("Welcome", "Glad to have you.", "Dr. Smith");
        assertEquals("Welcome", ann.getTitle());
        assertEquals("Glad to have you.", ann.getContent());
        assertEquals("Dr. Smith", ann.getAuthor());
    }

    // ==========================================
    // 7. COURSE GRADES & ROSTER TESTS
    // ==========================================
    @Test
    public void testCourseRosterManagement() {
        Course course = new Course("CS3411", "R01", "Systems Programming", "Prof. Johnson", "johnson@univ.edu");
        
        assertTrue(course.getEnrolledStudents().contains("student"));
        
        course.addStudent("alice");
        assertTrue(course.getEnrolledStudents().contains("alice"));
        
        course.removeStudent("alice");
        assertFalse(course.getEnrolledStudents().contains("alice"));

        course.clearRoster();
        assertTrue(course.getEnrolledStudents().isEmpty());
    }

    @Test
    public void testCourseWeightedGradeCalculations() {
        Course course = new Course("CS3141", "R01", "Software Engineering", "Dr. Smith", "smith@univ.edu");
        Assignment a1 = new Assignment("HW1", "12/31/2030 23:59", "Desc", 100.0);
        course.getAssignments().add(a1);

        // Submit and grade with fraction format "5/8" (62.5%)
        a1.submitWork("student", tempFilePath);
        a1.getSubmissionForStudent("student").setGrade("5/8");

        double percentage = course.getGradePercentage("student");
        assertEquals(62.5, percentage, 0.001);
        assertEquals("D", course.getLetterGrade("student"));
    }
}